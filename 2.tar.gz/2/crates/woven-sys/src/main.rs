//! woven-sys: bootstrap, hand control to Lua immediately.

mod compositor;
mod lua;
mod sys;

use anyhow::{Context, Result};
use mlua::prelude::*;
use std::sync::Arc;
use tokio::sync::RwLock;
use tracing::info;
use woven_common::types::{AnimationConfig, Theme};
use woven_render::RenderThread;

use compositor::HyprlandBackend;
use compositor::backend::CompositorBackend;
use lua::registry::AppState;

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
    .with_env_filter(
        tracing_subscriber::EnvFilter::from_env("WOVEN_LOG")
        .add_directive("woven=info".parse()?)
    )
    .init();

    info!("woven starting");

    let project_root = std::env::var("WOVEN_ROOT")
    .unwrap_or_else(|_| ".".to_string());
    let config_path = format!("{}/config/woven.lua", project_root);
    let runtime_dir = format!("{}/runtime", project_root);

    // detect compositor
    let backend: Arc<dyn CompositorBackend> = if HyprlandBackend::detect() {
        info!("compositor: hyprland");
        Arc::new(HyprlandBackend::new()?)
    } else {
        anyhow::bail!("No supported compositor detected. Supported: Hyprland");
    };

    let theme = Theme::default();
    let anims = AnimationConfig::default();

    // spawn render thread — owns the Wayland connection and draws everything
    let render = Arc::new(
        RenderThread::spawn(theme.clone(), anims.clone())
        .context("Failed to spawn render thread")?
    );

    // shared app state
    let state = Arc::new(AppState {
        backend,
        render:      render.clone(),
                         metrics:     Arc::new(RwLock::new(sys::proc_metrics::MetricsCollector::new())),
                         theme:       Arc::new(RwLock::new(theme)),
                         anims:       Arc::new(RwLock::new(anims)),
                         runtime_dir: runtime_dir.clone(),
                         config_path: config_path.clone(),
    });

    // build Lua VM
    let lua = Lua::new();

    lua::sandbox::apply(&lua)
    .context("Failed to apply Lua sandbox")?;

    lua::registry::bind(&lua, state)
    .context("Failed to bind Lua API")?;

    let boot_path = format!("{}/boot.lua", runtime_dir);
    let boot_code = std::fs::read_to_string(&boot_path)
    .with_context(|| format!("Could not read {}", boot_path))?;

    info!("handing control to Lua runtime");
    lua.load(&boot_code)
    .set_name("boot.lua")
    .exec()
    .map_err(|e| anyhow::anyhow!("Lua runtime error: {}", e))?;

    Ok(())
}
