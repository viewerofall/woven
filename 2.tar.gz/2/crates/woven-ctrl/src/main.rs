//! woven-ctrl: IPC bridge to the running woven daemon.
//!
//! Usage:
//!   woven-ctrl toggle          — show/hide overlay
//!   woven-ctrl show            — show overlay
//!   woven-ctrl hide            — hide overlay
//!   woven-ctrl reload          — reload config without restarting
//!   woven-ctrl status          — print daemon status as JSON
//!
//! Talks to the daemon via the unix socket at $WOVEN_SOCKET
//! (default: /tmp/woven-$USER.sock)

use anyhow::{Context, Result};
use std::io::{Read, Write};
use std::os::unix::net::UnixStream;
use woven_common::ipc::{IpcCommand, IpcResponse};

fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.is_empty() {
        eprintln!("Usage: woven-ctrl <command>");
        eprintln!("Commands: toggle  show  hide  reload  status");
        std::process::exit(1);
    }

    let cmd = match args[0].as_str() {
        "toggle" => IpcCommand::Toggle,
        "show"   => IpcCommand::Show,
        "hide"   => IpcCommand::Hide,
        "reload" => IpcCommand::ReloadConfig,
        "status" => IpcCommand::GetStatus,
        other    => {
            eprintln!("Unknown command: {}", other);
            std::process::exit(1);
        }
    };

    let socket_path = socket_path();
    let mut stream  = UnixStream::connect(&socket_path)
    .with_context(|| format!(
        "Could not connect to woven socket at {}\nIs woven running?",
        socket_path
    ))?;

    // send command as newline-delimited JSON
    let msg = serde_json::to_string(&cmd)? + "\n";
    stream.write_all(msg.as_bytes())
    .context("Failed to send command")?;

    // read response
    let mut buf = String::new();
    stream.read_to_string(&mut buf)
    .context("Failed to read response")?;

    if buf.is_empty() { return Ok(()); }

    let response: IpcResponse = serde_json::from_str(buf.trim())
    .context("Invalid response from daemon")?;

    match response {
        IpcResponse::Ok          => {}
        IpcResponse::Status(s)   => println!("{}", serde_json::to_string_pretty(&s)?),
        IpcResponse::Error(e)    => {
            eprintln!("Daemon error: {}", e);
            std::process::exit(1);
        }
    }

    Ok(())
}

fn socket_path() -> String {
    if let Ok(p) = std::env::var("WOVEN_SOCKET") { return p; }
    let user = std::env::var("USER").unwrap_or_else(|_| "user".into());
    format!("/tmp/woven-{}.sock", user)
}
