-- core/overlay.lua
-- Controls overlay show/hide/toggle state.
-- Also owns the main run loop that keeps woven alive.

local workspace = require("core.workspace")
local metrics   = require("core.metrics")

local M = { _visible = false }

function M.init()
woven.log.info("overlay: ready")

-- push initial workspace state to render thread immediately
M._push_state()

-- show overlay on startup so we can see something right away
-- later this will be triggered by the toggle key instead
M.show()

-- main run loop — keeps the process alive and polls state
M._loop()
end

function M._push_state()
local workspaces = woven.compositor.workspaces()
if workspaces then
    -- poll metrics for each workspace
    local all_metrics = {}
    for _, ws in ipairs(workspaces) do
        local m = woven.metrics.workspace(ws.id)
        if m then
            table.insert(all_metrics, m)
            end
            end
            woven.overlay.update_state(workspaces, all_metrics)
            end
            end

            function M._loop()
            woven.log.info("overlay: entering run loop")
            local tick = 0
            while true do
                tick = tick + 1

                -- refresh workspace state every 60 ticks (~2s at 30ms/tick)
                if tick % 60 == 0 then
                    workspace.refresh()
                    M._push_state()
                    end

                    -- sleep 30ms between ticks
                    woven.sleep(30)
                    end
                    end

                    function M.show()
                    M._visible = true
                    woven.overlay.show()
                    woven.log.info("overlay: shown")
                    end

                    function M.hide()
                    M._visible = false
                    woven.overlay.hide()
                    woven.log.info("overlay: hidden")
                    end

                    function M.toggle()
                    if M._visible then M.hide() else M.show() end
                        end

                        function M.is_visible()
                        return M._visible
                        end

                        return M
