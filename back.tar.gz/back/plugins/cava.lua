-- plugins/cava.lua
-- Mini spectrum visualizer for the expanded control-center bar.
-- Reads from cava's raw binary output via a named pipe.
--
-- Setup (run once, e.g. in your shell rc or compositor autostart):
--   mkfifo /tmp/woven-cava 2>/dev/null
--   cava -p ~/.config/woven/plugins/cava.ini &
--
-- Usage (in woven.lua):
--   require("plugins.cava").setup()

local M = {}
local FIFO    = "/tmp/woven-cava"
local N_BARS  = 16
local spawned = false

function M.setup(opts)
    opts = opts or {}

    local handle = woven.plugin.register({
        name = "cava",
        type = "bar_widget",
    })

    handle.widget({
        slot     = opts.slot     or "panel",
        height   = opts.height   or 72,
        interval = opts.interval or 0,   -- 0 = render every tick
        render   = function(ctx)
            -- Spawn cava once if not already running
            if not spawned then
                woven.process.spawn("sh", { "-c",
                    "mkfifo " .. FIFO .. " 2>/dev/null; " ..
                    "cava -p " .. woven.fs.config_path():gsub("woven.lua","") ..
                    "plugins/cava.ini" })
                spawned = true
            end

            -- Non-blocking read of N_BARS bytes from the fifo
            local raw = woven.io.read_bytes(FIFO, N_BARS)

            local w     = ctx.height * 0.9   -- use height as proxy for available width
            local bar_w = 10.0
            local gap   = 4.0
            local max_h = ctx.height - 8.0
            local base_y = ctx.height - 2.0

            -- accent gradient: low bars blue, high bars mauve/red
            local colors = {
                "#89b4fa", "#89b4fa", "#89dceb", "#89dceb",
                "#94e2d5", "#a6e3a1", "#a6e3a1", "#f9e2af",
                "#fab387", "#fab387", "#f38ba8", "#f38ba8",
                "#cba6f7", "#cba6f7", "#b4befe", "#b4befe",
            }

            for i = 1, N_BARS do
                local val = 0
                if raw then
                    val = raw:byte(i) or 0
                end
                local h = (val / 255.0) * max_h
                if h < 1.0 then h = 1.0 end
                local x = (i - 1) * (bar_w + gap)
                local col = colors[i] or "#89b4fa"
                ctx.rect(x, base_y - h, bar_w, h, { color = col, alpha = 0.85, radius = 2.0 })
            end
        end,
    })
end

return M
