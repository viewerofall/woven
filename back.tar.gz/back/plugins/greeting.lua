-- plugins/greeting.lua
-- Shows a time-of-day greeting + active workspace name in the overlay widget strip.
--
-- Usage (in woven.lua):
--   require("plugins.greeting").setup()

local M = {}

function M.setup(opts)
    opts = opts or {}

    local handle = woven.plugin.register({
        name = "greeting",
        type = "bar_widget",
    })

    handle.widget({
        slot     = opts.slot     or "overlay",
        height   = opts.height   or 40,
        interval = opts.interval or 60,
        render   = function(ctx)
            local t = woven.now()
            local greet
            if     t.hour < 5  then greet = "up late?"
            elseif t.hour < 12 then greet = "good morning"
            elseif t.hour < 17 then greet = "good afternoon"
            elseif t.hour < 21 then greet = "good evening"
            else                     greet = "good night"
            end

            ctx.text(greet, {
                x = 4, y = ctx.height / 2 + 4,
                size = 13, color = "#cba6f7", alpha = 0.75,
            })
        end,
    })
end

return M
