//! woven-via: Wayland surface operation hypervisor.
//!
//! # The law
//!
//! zwlr_layer_surface_v1 has one unbreakable rule:
//!   Every wl_surface.commit() that carries layer-shell state changes MUST
//!   be preceded by ack_configure() for the compositor's latest configure.
//!   SCT's layer_surface.commit() handles this automatically.
//!   Raw wl_surface.commit() does NOT. Never call it directly.
//!
//! # Why null-buffer hide doesn't work for power cycles
//!
//! The classic "attach(None) + commit" unmaps the surface. To re-map, the
//! compositor must send a fresh configure, which the client must ack, before
//! committing a real buffer. But there is no standard way to *request* that
//! configure — you have to commit something, which is invalid on an unmapped
//! surface. This is the infinite loop that caused every "Protocol error 1".
//!
//! # The solution: never unmap
//!
//! After first_show(), the surface stays mapped forever. "Hide" means:
//!   - Stage keyboard_interactivity = None  (releases focus to underlying windows)
//!   - The next present() commits this change with a real buffer (transparent)
//!
//! "Show" means:
//!   - Stage keyboard_interactivity = Exclusive
//!   - The next present() commits this change with a real buffer (visible)
//!
//! No null-buffer commits. No remap configure cycle. No Protocol error 1.
//!
//! # State machine
//! ```text
//!  ┌──────────┐  first_show()   ┌──────────────────┐  configure arrives
//!  │ Unmapped │ ──────────────► │ WaitingConfigure │ ──────────────────►
//!  └──────────┘                 └──────────────────┘
//!                                                         │
//!                                                         ▼
//!                                               ┌──────────────────┐
//!                              ◄── begin_hide() │     Mapped       │ ◄── begin_show()
//!                              ──── begin_show() ──► (keyboard      │
//!                                               │    tracked here) │
//!                                               └──────────────────┘
//!                                                   │  present() always valid here
//! ```
//!
//! # Power cycle law (startup → shutdown → startup)
//!
//! BOOT:       Unmapped → first_show() → WaitingConfigure → configure → Mapped
//! SHOW:       begin_show() — stages keyboard=Exclusive, present() commits it
//! HIDE:       begin_hide() — stages keyboard=None, present() commits it
//! SHUTDOWN:   process exits, Wayland objects destroyed by OS
//! REBOOT:     New process, new connection, new Via — always starts Unmapped
//!
//! There is NO reshow/remap path. Every process lifetime does exactly ONE
//! first_show(). Repeated show/hide cycles are keyboard toggles only.
//!
//! # In-process restart (hypervisor loopback)
//!
//! On fatal state or protocol violation, Via does not exit the process. It panics
//! with `ViaRestartRequested`. The render thread catches this, drops the current
//! connection/surface, creates a new one (new Via), and continues. So the
//! "mini computer" re-executes its surface lifecycle inside the same process.

use std::fmt;

/// Panic payload used by Via when it requests an in-process restart.
/// The render loop catches this, tears down the current surface/connection,
/// creates a new one, and continues (no process exit).
#[derive(Debug, Clone, Copy)]
pub struct ViaRestartRequested;

use smithay_client_toolkit::shell::{
    WaylandSurface,
    wlr_layer::{KeyboardInteractivity, LayerSurface as SctLayerSurface},
};
use wayland_client::protocol::wl_shm;
use tracing::{debug, error, info, warn};

// ─────────────────────────────────────────────────────────────────────────────
// State
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SurfaceState {
    /// Process just started. No Wayland commits issued.
    Unmapped,
    /// first_show() commit sent. Waiting for compositor configure.
    WaitingConfigure,
    /// Configured and mapped. Surface stays here for entire process lifetime.
    /// keyboard_exclusive tracks whether we have input focus.
    Mapped { width: u32, height: u32, keyboard_exclusive: bool },
}

impl fmt::Display for SurfaceState {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Unmapped                                      => write!(f, "Unmapped"),
            Self::WaitingConfigure                             => write!(f, "WaitingConfigure"),
            Self::Mapped { width, height, keyboard_exclusive } =>
            write!(f, "Mapped({width}x{height} kb={keyboard_exclusive})"),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Via
// ─────────────────────────────────────────────────────────────────────────────

pub struct Via {
    state:           SurfaceState,
    configure_count: u64,
    commit_count:    u64,
    /// Keyboard interactivity change staged, waiting for next present() commit.
    pending_kb:      Option<KeyboardInteractivity>,
}

impl Via {
    pub fn new() -> Self {
        Self {
            state:           SurfaceState::Unmapped,
            configure_count: 0,
            commit_count:    0,
            pending_kb:      None,
        }
    }

    // ── compositor events ────────────────────────────────────────────────────

    /// Call from LayerShellHandler::configure.
    pub fn on_configure(&mut self, width: u32, height: u32) {
        self.configure_count += 1;
        debug!("via: configure #{} {}x{} state={}", self.configure_count, width, height, self.state);
        match &self.state {
            SurfaceState::WaitingConfigure => {
                self.state = SurfaceState::Mapped {
                    width,
                    height,
                    keyboard_exclusive: true, // first_show sets Exclusive (grab so user can close with key)
                };
                info!("via: configured → {}", self.state);
            }
            SurfaceState::Mapped { keyboard_exclusive, .. } => {
                // Size update from compositor (e.g. monitor resize). Keep kb state.
                let kb = *keyboard_exclusive;
                if width > 0 && height > 0 {
                    self.state = SurfaceState::Mapped { width, height, keyboard_exclusive: kb };
                    debug!("via: size updated → {}", self.state);
                }
            }
            SurfaceState::Unmapped => {
                warn!("via: configure arrived in Unmapped state — ignoring");
            }
        }
    }

    // ── surface lifecycle ─────────────────────────────────────────────────────

    /// ONE-TIME initial map. Called exactly once per process lifetime.
    /// Commits anchor + exclusive_zone + keyboard=Exclusive + size=0.
    /// Caller must poll until is_mapped() returns true (configure arrives).
    pub fn first_show(&mut self, layer: &SctLayerSurface) {
        self.assert("first_show", &["Unmapped"]);
        layer.set_size(0, 0);
        layer.set_keyboard_interactivity(KeyboardInteractivity::Exclusive);
        self.do_commit(layer, "first_show");
        self.state = SurfaceState::WaitingConfigure;
        info!("via: first_show → WaitingConfigure");
    }

    /// Stage keyboard=Exclusive for the next present().
    /// Safe to call any number of times — idempotent.
    pub fn begin_show(&mut self, layer: &SctLayerSurface) {
        match &self.state {
            SurfaceState::Mapped { keyboard_exclusive: true, .. } => {
                debug!("via: begin_show — already exclusive, no-op");
                return;
            }
            SurfaceState::Mapped { .. } => {}
            SurfaceState::WaitingConfigure => {
                debug!("via: begin_show during WaitingConfigure — will apply after configure");
                self.pending_kb = Some(KeyboardInteractivity::Exclusive);
                return;
            }
            _ => {
                self.halt("begin_show() called before first_show()");
            }
        }
        layer.set_keyboard_interactivity(KeyboardInteractivity::Exclusive);
        self.pending_kb = Some(KeyboardInteractivity::Exclusive);
        debug!("via: begin_show staged");
    }

    /// Stage keyboard=None for the next present().
    /// Surface stays mapped — compositor retains no special reference to it.
    pub fn begin_hide(&mut self, layer: &SctLayerSurface) {
        match &self.state {
            SurfaceState::Mapped { keyboard_exclusive: false, .. } => {
                debug!("via: begin_hide — already non-exclusive, no-op");
                return;
            }
            SurfaceState::Mapped { .. } => {}
            SurfaceState::WaitingConfigure => {
                self.pending_kb = Some(KeyboardInteractivity::None);
                return;
            }
            _ => {
                warn!("via: begin_hide() called before first_show() — ignoring");
                return;
            }
        }
        layer.set_keyboard_interactivity(KeyboardInteractivity::None);
        self.pending_kb = Some(KeyboardInteractivity::None);
        debug!("via: begin_hide staged");
    }

    // ── present ──────────────────────────────────────────────────────────────

    /// Present a frame. The ONLY path that issues wl_surface.commit().
    /// Handles pending keyboard state changes automatically.
    pub fn present(
        &mut self,
        layer:  &SctLayerSurface,
        pool:   &mut smithay_client_toolkit::shm::slot::SlotPool,
        pixels: &[u8],
        width:  u32,
        height: u32,
    ) -> anyhow::Result<()> {
        match &self.state {
            SurfaceState::Mapped { .. }     => {}
            SurfaceState::WaitingConfigure  => {
                debug!("via: present() skipped — WaitingConfigure");
                return Ok(());
            }
            SurfaceState::Unmapped => {
                self.halt("present() called before first_show()");
            }
        }

        let stride = width * 4;
        let (buffer, canvas) = pool
        .create_buffer(width as i32, height as i32, stride as i32, wl_shm::Format::Argb8888)
        .map_err(|e| anyhow::anyhow!("create_buffer: {e:?}"))?;

        let n = canvas.len().min(pixels.len());
        canvas[..n].copy_from_slice(&pixels[..n]);

        let surf = layer.wl_surface();
        buffer.attach_to(surf).map_err(|e| anyhow::anyhow!("attach: {e:?}"))?;
        surf.damage_buffer(0, 0, width as i32, height as i32);

        // layer.commit() = ack_configure (SCT-managed) + wl_surface.commit().
        // Any pending keyboard state staged by begin_show/begin_hide was already
        // sent via layer.set_keyboard_interactivity() and will be applied here.
        self.do_commit(layer, "present");

        // Update our keyboard tracking after the commit.
        if let Some(kb) = self.pending_kb.take() {
            if let SurfaceState::Mapped { width: w, height: h, .. } = self.state {
                self.state = SurfaceState::Mapped {
                    width: w, height: h,
                    keyboard_exclusive: kb == KeyboardInteractivity::Exclusive,
                };
            }
        }

        Ok(())
    }

    // ── queries ───────────────────────────────────────────────────────────────

    pub fn is_mapped(&self) -> bool {
        matches!(self.state, SurfaceState::Mapped { .. })
    }

    pub fn is_keyboard_exclusive(&self) -> bool {
        matches!(self.state, SurfaceState::Mapped { keyboard_exclusive: true, .. })
    }

    pub fn state(&self) -> &SurfaceState { &self.state }

    pub fn dims(&self) -> Option<(u32, u32)> {
        if let SurfaceState::Mapped { width, height, .. } = &self.state {
            Some((*width, *height))
        } else { None }
    }

    // ── internals ────────────────────────────────────────────────────────────

    fn do_commit(&mut self, layer: &SctLayerSurface, op: &str) {
        self.commit_count += 1;
        debug!("via: commit #{} op={op} state={}", self.commit_count, self.state);
        layer.commit();
    }

    fn assert(&self, op: &str, valid: &[&str]) {
        let tag = match &self.state {
            SurfaceState::Unmapped          => "Unmapped",
            SurfaceState::WaitingConfigure  => "WaitingConfigure",
            SurfaceState::Mapped {..}       => "Mapped",
        };
        if !valid.contains(&tag) {
            self.halt(&format!(
                "{op}() in state {tag} — expected one of: {}",
                               valid.join(", ")
            ));
        }
    }

    fn halt(&self, reason: &str) -> ! {
        error!(
            "┌─ woven-via: SURFACE PROTOCOL VIOLATION (requesting in-process restart) ─\n\
│  reason:          {}\n\
│  current state:   {}\n\
│  configure_count: {}\n\
│  commit_count:    {}\n\
└──────────────────────────────────────────────────────────",
reason, self.state, self.configure_count, self.commit_count
        );
        std::panic::panic_any(ViaRestartRequested);
    }
}

impl Default for Via { fn default() -> Self { Self::new() } }
