//! wlr-layer-shell surface + seat/pointer.
//! All commits route through woven_via::Via (never unmap; show/hide = keyboard toggle).
//! Cursor fix: set_cursor must be called inside pointer_frame (enter event),
//! not at capability time — that's when the compositor actually hands us the serial.

use anyhow::{Context, Result};
use smithay_client_toolkit::{
    compositor::{CompositorHandler, CompositorState},
    output::{OutputHandler, OutputState},
    registry::{ProvidesRegistryState, RegistryState},
    registry_handlers,
    seat::{
        Capability, SeatHandler, SeatState,
        keyboard::{KeyboardHandler, KeyEvent, Keysym, Modifiers, RepeatInfo},
        pointer::{
            CursorIcon, PointerEvent, PointerEventKind,
            PointerHandler, ThemedPointer, ThemeSpec,
        },
    },
    shell::{
        wlr_layer::{
            Anchor, KeyboardInteractivity, Layer, LayerShell, LayerShellHandler,
            LayerSurface as SctLayerSurface, LayerSurfaceConfigure,
        },
    },
    shm::{slot::SlotPool, Shm, ShmHandler},
};
use wayland_client::{
    globals::registry_queue_init,
    protocol::{wl_keyboard, wl_output, wl_pointer, wl_seat, wl_surface},
    Connection, EventQueue, QueueHandle,
};
use crossbeam_channel::Sender;
use tracing::info;
use woven_via::Via;

/// Input events forwarded to the render thread
#[derive(Debug, Clone)]
pub enum MouseEvent {
    Motion      { x: f64, y: f64 },
    Scroll      { dx: f64, dy: f64 },
    Press       { x: f64, y: f64 },
    RightPress  { x: f64, y: f64 },
    Release     { x: f64, y: f64 },
    Key         { keysym: u32 },
}

pub struct LayerSurface {
    queue: EventQueue<WovenState>,
    state: WovenState,
    via:   Via,
}

impl LayerSurface {
    pub fn new(mouse_tx: Sender<MouseEvent>) -> Result<Self> {
        let conn = Connection::connect_to_env()
        .context("Failed to connect to Wayland display")?;
        let (globals, queue) = registry_queue_init::<WovenState>(&conn)
        .context("Failed to init Wayland registry")?;
        let qh = queue.handle();

        let compositor  = CompositorState::bind(&globals, &qh).context("wl_compositor missing")?;
        let layer_shell = LayerShell::bind(&globals, &qh).context("wlr-layer-shell missing")?;
        let shm         = Shm::bind(&globals, &qh).context("wl_shm missing")?;
        let seat_state  = SeatState::new(&globals, &qh);

        let surface = compositor.create_surface(&qh);
        let layer_surface = layer_shell.create_layer_surface(
            &qh, surface, Layer::Overlay,
            Some("woven-overlay"), None,
        );
        layer_surface.set_anchor(Anchor::all());
        layer_surface.set_exclusive_zone(-1);
        // Don't set keyboard interactivity or commit here — we're not visible yet.
        // The compositor will send a configure when we commit on first show().
        layer_surface.set_keyboard_interactivity(KeyboardInteractivity::None);
        layer_surface.set_size(0, 0);
        // No commit — surface stays unmapped until show() is called.

        let pool = SlotPool::new(8 * 1024 * 1024, &shm).context("shm pool failed")?;

        let state = WovenState {
            registry:          RegistryState::new(&globals),
            compositor,
            output_state:      OutputState::new(&globals, &qh),
            seat_state,
            shm,
            layer_surface,
            pool,
            pointer:           None,
            keyboard:          None,
            mouse_tx,
            mouse_x:           0.0,
            mouse_y:           0.0,
            width:             0,
            height:            0,
            configured:        false,
            visible:           false,
            pending_configure: None,
        };

        Ok(Self { queue, state, via: Via::new() })
    }

    pub fn show(&mut self) -> Result<()> {
        self.state.visible = true;
        match self.via.state() {
            woven_via::SurfaceState::Unmapped => {
                self.via.first_show(&self.state.layer_surface);
                let deadline = std::time::Instant::now() + std::time::Duration::from_millis(500);
                while !self.via.is_mapped() && std::time::Instant::now() < deadline {
                    let _ = self.queue.flush();
                    if let Some(guard) = self.queue.prepare_read() {
                        let _ = guard.read();
                    }
                    self.dispatch_inner()?;
                }
                if !self.via.is_mapped() {
                    tracing::warn!("compositor never sent configure — overlay may not display");
                }
            }
            _ => {
                self.via.begin_show(&self.state.layer_surface);
            }
        }
        Ok(())
    }

    /// Hide = stage keyboard=None for next present(). No unmap (avoids protocol error 1).
    pub fn hide(&mut self) -> Result<()> {
        self.state.visible = false;
        self.via.begin_hide(&self.state.layer_surface);
        let _ = self.queue.flush();
        Ok(())
    }

    // Keyboard interactivity is set once at map time and never changed mid-flight.
    // Changing zwlr_layer_surface state requires an ack_configure cycle; doing it
    // via raw wl_surface.commit() (present) skips the ack and causes error 1.
    pub fn release_input(&mut self) {}
    pub fn grab_input(&mut self) {}

    pub fn is_visible(&self) -> bool { self.state.visible }

    pub fn size(&self) -> (u32, u32) {
        self.via.dims().unwrap_or((self.state.width, self.state.height))
    }

    /// Dispatches Wayland events and forwards configure to Via.
    pub fn dispatch(&mut self) -> Result<()> {
        self.dispatch_inner()?;
        if let Some((w, h)) = self.state.pending_configure.take() {
            self.via.on_configure(w, h);
            if w > 0 {
                self.state.width = w;
            }
            if h > 0 {
                self.state.height = h;
            }
        }
        Ok(())
    }

    fn dispatch_inner(&mut self) -> Result<()> {
        // Flush outgoing events first
        if let Err(e) = self.queue.flush() {
            tracing::debug!("wayland flush skipped: {}", e);
        }

        // Non-blocking read: only consume events already in the socket buffer.
        // We poll the Wayland fd with timeout=0 so we never stall the render loop
        // waiting for the compositor to send something.
        if let Some(guard) = self.queue.prepare_read() {
            use std::os::unix::io::AsRawFd;
            use rustix::fd::AsFd;
            use rustix::event::{PollFd, PollFlags, poll};
            use rustix::time::Timespec;
            let raw = self.queue.as_fd().as_raw_fd();
            let borrowed = unsafe { rustix::fd::BorrowedFd::borrow_raw(raw) };
            let mut pfd = PollFd::new(&borrowed, PollFlags::IN);
            let ts = Timespec { tv_sec: 0, tv_nsec: 0 };
            let ready = poll(std::slice::from_mut(&mut pfd), Some(&ts)).unwrap_or(0);
            if ready > 0 && pfd.revents().contains(PollFlags::IN) {
                let _ = guard.read();
            } else {
                drop(guard);
            }
        }

        self.queue.dispatch_pending(&mut self.state).context("dispatch failed")?;
        Ok(())
    }

    /// Present a frame. All commits go through Via (ack_configure + commit).
    pub fn present(&mut self, pixels: Vec<u8>, width: u32, height: u32) -> Result<()> {
        if !self.state.visible {
            return Ok(());
        }
        self.via.present(
            &self.state.layer_surface,
            &mut self.state.pool,
            &pixels,
            width,
            height,
        )
        .context("via.present failed")?;
        Ok(())
    }
}

// ── Wayland state ─────────────────────────────────────────────────────────────

struct WovenState {
    registry:          RegistryState,
    compositor:        CompositorState,
    output_state:     OutputState,
    seat_state:       SeatState,
    shm:               Shm,
    layer_surface:    SctLayerSurface,
    pool:              SlotPool,
    pointer:          Option<ThemedPointer>,
    keyboard:         Option<wl_keyboard::WlKeyboard>,
    mouse_tx:          Sender<MouseEvent>,
    mouse_x:           f64,
    mouse_y:           f64,
    width:             u32,
    height:            u32,
    configured:        bool,
    visible:           bool,
    /// Staged from LayerShellHandler::configure; consumed in dispatch() and forwarded to Via.
    pending_configure:  Option<(u32, u32)>,
}

impl CompositorHandler for WovenState {
    fn scale_factor_changed(&mut self, _: &Connection, _: &QueueHandle<Self>, _: &wl_surface::WlSurface, _: i32) {}
    fn transform_changed(&mut self, _: &Connection, _: &QueueHandle<Self>, _: &wl_surface::WlSurface, _: wl_output::Transform) {}
    fn frame(&mut self, _: &Connection, _: &QueueHandle<Self>, _: &wl_surface::WlSurface, _: u32) {}
    fn surface_enter(&mut self, _: &Connection, _: &QueueHandle<Self>, _: &wl_surface::WlSurface, _: &wl_output::WlOutput) {}
    fn surface_leave(&mut self, _: &Connection, _: &QueueHandle<Self>, _: &wl_surface::WlSurface, _: &wl_output::WlOutput) {}
}

impl OutputHandler for WovenState {
    fn output_state(&mut self) -> &mut OutputState { &mut self.output_state }
    fn new_output(&mut self, _: &Connection, _: &QueueHandle<Self>, _: wl_output::WlOutput) {}
    fn update_output(&mut self, _: &Connection, _: &QueueHandle<Self>, _: wl_output::WlOutput) {}
    fn output_destroyed(&mut self, _: &Connection, _: &QueueHandle<Self>, _: wl_output::WlOutput) {}
}

impl SeatHandler for WovenState {
    fn seat_state(&mut self) -> &mut SeatState { &mut self.seat_state }
    fn new_seat(&mut self, _: &Connection, _: &QueueHandle<Self>, _: wl_seat::WlSeat) {}
    fn remove_seat(&mut self, _: &Connection, _: &QueueHandle<Self>, _: wl_seat::WlSeat) {}

    fn new_capability(&mut self, _conn: &Connection, qh: &QueueHandle<Self>,
                      seat: wl_seat::WlSeat, cap: Capability)
    {
        if cap == Capability::Pointer && self.pointer.is_none() {
            let cursor_surf = self.compositor.create_surface(qh);
            match self.seat_state.get_pointer_with_theme(
                qh, &seat, self.shm.wl_shm(), cursor_surf, ThemeSpec::System,
            ) {
                Ok(ptr) => {
                    self.pointer = Some(ptr);
                    info!("seat: pointer ready");
                }
                Err(e) => tracing::warn!("pointer init failed: {}", e),
            }
        }
        if cap == Capability::Keyboard && self.keyboard.is_none() {
            match self.seat_state.get_keyboard(qh, &seat, None) {
                Ok(kb) => {
                    self.keyboard = Some(kb);
                    info!("seat: keyboard ready");
                }
                Err(e) => tracing::warn!("keyboard init failed: {}", e),
            }
        }
    }

    fn remove_capability(&mut self, _: &Connection, _: &QueueHandle<Self>,
                         _: wl_seat::WlSeat, cap: Capability)
    {
        if cap == Capability::Pointer  { self.pointer  = None; }
        if cap == Capability::Keyboard { self.keyboard = None; }
    }
}

impl KeyboardHandler for WovenState {
    fn enter(&mut self, _: &Connection, _: &QueueHandle<Self>,
             _: &wl_keyboard::WlKeyboard,
             _: &wl_surface::WlSurface, _: u32, _: &[u32], _: &[Keysym]) {}

             fn leave(&mut self, _: &Connection, _: &QueueHandle<Self>,
                      _: &wl_keyboard::WlKeyboard,
                      _: &wl_surface::WlSurface, _: u32) {}

                      fn press_key(&mut self, _: &Connection, _: &QueueHandle<Self>,
                                   _: &wl_keyboard::WlKeyboard,
                                   _: u32, event: KeyEvent)
                      {
                          let _ = self.mouse_tx.try_send(MouseEvent::Key { keysym: event.keysym.raw() });
                      }

                      fn release_key(&mut self, _: &Connection, _: &QueueHandle<Self>,
                                     _: &wl_keyboard::WlKeyboard,
                                     _: u32, _: KeyEvent) {}

                                     fn update_modifiers(&mut self, _: &Connection, _: &QueueHandle<Self>,
                                                         _: &wl_keyboard::WlKeyboard,
                                                         _: u32, _: Modifiers, _: smithay_client_toolkit::seat::keyboard::RawModifiers, _: u32) {}

                                                         fn repeat_key(&mut self, _: &Connection, _: &QueueHandle<Self>,
                                                                       _: &wl_keyboard::WlKeyboard,
                                                                       _: u32, event: KeyEvent) {
                                                             let _ = self.mouse_tx.try_send(MouseEvent::Key { keysym: event.keysym.raw() });
                                                                       }

                                                                       fn update_repeat_info(&mut self, _: &Connection, _: &QueueHandle<Self>,
                                                                                             _: &wl_keyboard::WlKeyboard, _: RepeatInfo) {}
}

impl PointerHandler for WovenState {
    fn pointer_frame(&mut self, conn: &Connection, _qh: &QueueHandle<Self>,
                     _: &wl_pointer::WlPointer, events: &[PointerEvent])
    {
        for ev in events {
            match ev.kind {
                // Enter: set cursor AND send initial position so hover works immediately
                PointerEventKind::Enter { .. } => {
                    if let Some(ptr) = &self.pointer {
                        let _ = ptr.set_cursor(conn, CursorIcon::Default);
                    }
                    self.mouse_x = ev.position.0;
                    self.mouse_y = ev.position.1;
                    let _ = self.mouse_tx.try_send(MouseEvent::Motion {
                        x: self.mouse_x, y: self.mouse_y,
                    });
                }
                PointerEventKind::Motion { time: _ } => {
                    self.mouse_x = ev.position.0;
                    self.mouse_y = ev.position.1;
                    let _ = self.mouse_tx.try_send(MouseEvent::Motion {
                        x: self.mouse_x, y: self.mouse_y,
                    });
                }
                PointerEventKind::Press { button, .. } => {
                    if button == 273 {
                        let _ = self.mouse_tx.try_send(MouseEvent::RightPress {
                            x: self.mouse_x, y: self.mouse_y,
                        });
                    } else {
                        let _ = self.mouse_tx.try_send(MouseEvent::Press {
                            x: self.mouse_x, y: self.mouse_y,
                        });
                    }
                }
                PointerEventKind::Release { button, .. } => {
                    let _ = self.mouse_tx.try_send(MouseEvent::Release {
                        x: self.mouse_x, y: self.mouse_y,
                    });
                    let _ = button;
                }
                PointerEventKind::Axis { horizontal, vertical, .. } => {
                    let _ = self.mouse_tx.try_send(MouseEvent::Scroll {
                        dx: horizontal.absolute,
                        dy: vertical.absolute,
                    });
                }
                _ => {}
            }
        }
    }
}

impl LayerShellHandler for WovenState {
    fn closed(&mut self, _: &Connection, _: &QueueHandle<Self>, _: &SctLayerSurface) {}
    fn configure(&mut self, _: &Connection, _: &QueueHandle<Self>,
                 _: &SctLayerSurface, cfg: LayerSurfaceConfigure, _serial: u32)
    {
        if cfg.new_size.0 > 0 {
            self.width = cfg.new_size.0;
        }
        if cfg.new_size.1 > 0 {
            self.height = cfg.new_size.1;
        }
        self.configured = true;
        self.pending_configure = Some((cfg.new_size.0, cfg.new_size.1));
        tracing::debug!("surface configured: {}x{}", self.width, self.height);
    }
}

impl ShmHandler for WovenState {
    fn shm_state(&mut self) -> &mut Shm { &mut self.shm }
}

impl ProvidesRegistryState for WovenState {
    fn registry(&mut self) -> &mut RegistryState { &mut self.registry }
    registry_handlers![OutputState, SeatState];
}

smithay_client_toolkit::delegate_compositor!(WovenState);
smithay_client_toolkit::delegate_output!(WovenState);
smithay_client_toolkit::delegate_seat!(WovenState);
smithay_client_toolkit::delegate_keyboard!(WovenState);
smithay_client_toolkit::delegate_pointer!(WovenState);
smithay_client_toolkit::delegate_layer!(WovenState);
smithay_client_toolkit::delegate_shm!(WovenState);
smithay_client_toolkit::delegate_registry!(WovenState);
