//! Window thumbnail cache — backed by `woven_protocols::ScreencopyManager`.
//!
//! # Usage in the render loop
//! ```rust,ignore
//! // On overview open:
//! capturer.request_all(&windows);
//!
//! // Every render tick while overview is visible:
//! capturer.pump();
//!
//! // Draw a card:
//! if let Some(thumb) = capturer.get("0x1a2b") {
//!     let (w, h, pixels) = thumb;
//!     draw.blit_xrgb(x, y, card_w, card_h, w, h, pixels);
//! }
//! ```

use std::collections::HashMap;
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

use tracing::{info, warn};
use woven_protocols::{CaptureRequest, ScreencopyManager};
use woven_common::types::{Rect, Window};

/// (width, height, XRGB8888 pixels scaled to card size)
pub type Thumbnail = (u32, u32, Vec<u8>);

/// Maps window id string → scaled-down thumbnail pixels.
pub type ThumbnailCache = HashMap<String, Thumbnail>;

/// Target card thumbnail size for the overview (pixels).
const THUMB_W: u32 = 320;
const THUMB_H: u32 = 180;

pub struct ThumbnailCapturer {
    manager: ScreencopyManager,
    /// window id string → (thumbnail_w, thumbnail_h, xrgb8888 bytes)
    cache: ThumbnailCache,
    /// Tracks which window ids have in-flight requests (window_id_u64 → id_str)
    in_flight: HashMap<u64, String>,
}

impl ThumbnailCapturer {
    /// Returns `None` if `zwlr_screencopy_manager_v1` is not available.
    pub fn new() -> Option<Self> {
        match ScreencopyManager::spawn() {
            Ok(mgr) => Some(Self {
                manager:   mgr,
                cache:     HashMap::new(),
                in_flight: HashMap::new(),
            }),
            Err(e) => {
                warn!("screencopy unavailable: {e:#} — overview will use placeholder cards");
                None
            }
        }
    }

    /// Schedule captures for a list of windows.  Skips windows with zero-area
    /// geometry.  Results arrive via `pump()`.
    pub fn request_all(&mut self, windows: &[(&str, &Rect)]) {
        let requests: Vec<CaptureRequest> = windows
            .iter()
            .filter(|(_, rect)| rect.w > 0 && rect.h > 0)
            .map(|(id, rect)| {
                let wid = hash_id(id);
                self.in_flight.insert(wid, id.to_string());
                CaptureRequest {
                    window_id:  wid,
                    output_idx: 0,
                    x: rect.x,
                    y: rect.y,
                    w: rect.w,
                    h: rect.h,
                }
            })
            .collect();

        info!("screencopy: requesting {} thumbnails", requests.len());
        self.manager.request_batch(requests);
    }

    /// Convenience wrapper for `Window` slices.
    pub fn request_windows(&mut self, windows: &[Window]) {
        let pairs: Vec<(&str, &Rect)> = windows
            .iter()
            .map(|w| (w.id.as_str(), &w.geometry))
            .collect();
        self.request_all(&pairs);
    }

    /// Drain completed frames from the screencopy thread and update the cache.
    /// Call this every render tick while the overview is visible.
    pub fn pump(&mut self) {
        for frame in self.manager.drain() {
            let Some(id_str) = self.in_flight.remove(&frame.window_id) else {
                continue;
            };
            // Scale to card size.
            let pixels = frame.scale_nearest(THUMB_W, THUMB_H);
            self.cache.insert(id_str, (THUMB_W, THUMB_H, pixels));
        }
    }

    /// Look up a cached thumbnail by compositor window id string.
    pub fn get(&self, window_id: &str) -> Option<&Thumbnail> {
        self.cache.get(window_id)
    }

    pub fn cache(&self) -> &ThumbnailCache {
        &self.cache
    }

    pub fn clear(&mut self) {
        self.cache.clear();
        self.in_flight.clear();
    }
}

/// Stable u64 hash of a compositor window id string.
fn hash_id(id: &str) -> u64 {
    // Fast path: Hyprland uses hex window addresses like "0x1a2b3c4d"
    if let Some(hex) = id.strip_prefix("0x").or_else(|| id.strip_prefix("0X")) {
        if let Ok(v) = u64::from_str_radix(hex, 16) {
            return v;
        }
    }
    let mut h = DefaultHasher::new();
    id.hash(&mut h);
    h.finish()
}

